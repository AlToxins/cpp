/**
 * @file blackclass.cpp
 * @brief 空类的大小为1字节
 * @author 光城
 * @version v1
 * @date 2019-07-21
 */

#include<iostream>
#include<bits/stdc++.h>
using namespace std;
#include<graphics.h> // use size in graphics also
class A{};
int main()
{
    cout<<sizeof(A)<<endl;
    cout<<sizeof
    return 0;
}
