extern const int ext=12;
