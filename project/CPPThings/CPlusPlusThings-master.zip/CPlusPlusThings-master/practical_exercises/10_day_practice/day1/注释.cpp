#include<iostream>


一种条件编译指令注释


//另一种注释方法
#if 0
asd
#endif

//打开注释
//条件编译指令
#if 1
asData
#endif
